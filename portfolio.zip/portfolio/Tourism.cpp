//#include <iostream>
//#include <cstring>
//
//using namespace std;
//
//int main() {
//    // Arrays for tour packages
//    int packageIDs[100];
//    char packageNames[100][100];
//    char packageDescriptions[100][256];
//    double packagePrices[100];
//    char packageItineraries[100][256];
//
//    int numTourPackages = 0;
//    int nextTourPackageID = 1;
//
//    // Arrays for bookings
//    int bookingIDs[100];
//    int bookingPackageIDs[100];
//    int bookingUserIDs[100];
//    char bookingStatuses[100][20];
//    double bookingPayments[100];
//
//    int numBookings = 0;
//    int nextBookingID = 1;
//
//    // Arrays for hotels
//    int hotelIDs[100];
//    char hotelNames[100][100];
//    char hotelLocations[100][100];
//    int hotelRoomsAvailable[100];
//    double hotelRoomPrices[100];
//
//    int numHotels = 0;
//    int nextHotelID = 1;
//
//    // Arrays for reviews
//    int reviewIDs[100];
//    int reviewHotelIDs[100];
//    int reviewUserIDs[100];
//    int reviewRatings[100];
//    char reviewComments[100][256];
//
//    int numReviews = 0;
//    int nextReviewID = 1;
//
//    while (true) {
//        cout << "Tourism Management System\n";
//        cout << "1. Manage Tour Packages\n";
//        cout << "2. Manage Bookings\n";
//        cout << "3. Manage Hotels\n";
//        cout << "4. Manage Reviews\n";
//        cout << "5. Exit\n";
//        cout << "Enter your choice: ";
//        int choice;
//        cin >> choice;
//
//        if (choice == 1) {
//            cout << "1. Create Tour Package\n";
//            cout << "2. Edit Tour Package\n";
//            cout << "3. Delete Tour Package\n";
//            cout << "4. View Tour Packages\n";
//            cout << "Enter your choice: ";
//            int tourChoice;
//            cin >> tourChoice;
//
//            if (tourChoice == 1) {
//                // Create Tour Package
//                if (numTourPackages < 100) {
//                    packageIDs[numTourPackages] = nextTourPackageID++;
//                    cout << "Enter package name: ";
//                    cin.ignore();
//                    cin.getline(packageNames[numTourPackages], 100);
//                    cout << "Enter package description: ";
//                    cin.getline(packageDescriptions[numTourPackages], 256);
//                    cout << "Enter package price: ";
//                    cin >> packagePrices[numTourPackages];
//                    cout << "Enter package itinerary: ";
//                    cin.ignore();
//                    cin.getline(packageItineraries[numTourPackages], 256);
//                    numTourPackages++;
//                    cout << "Tour package created successfully.\n";
//                }
//                else {
//                    cout << "Max tour packages reached.\n";
//                }
//            }
//            else if (tourChoice == 2) {
//                // Edit Tour Package
//                int id;
//                cout << "Enter package ID to edit: ";
//                cin >> id;
//                bool found = false;
//                for (int i = 0; i < numTourPackages; ++i) {
//                    if (packageIDs[i] == id) {
//                        cout << "Enter new package name: ";
//                        cin.ignore();
//                        cin.getline(packageNames[i], 100);
//                        cout << "Enter new package description: ";
//                        cin.getline(packageDescriptions[i], 256);
//                        cout << "Enter new package price: ";
//                        cin >> packagePrices[i];
//                        cout << "Enter new package itinerary: ";
//                        cin.ignore();
//                        cin.getline(packageItineraries[i], 256);
//                        cout << "Tour package updated successfully.\n";
//                        found = true;
//                        break;
//                    }
//                }
//                if (!found) {
//                    cout << "Package ID not found.\n";
//                }
//            }
//            else if (tourChoice == 3) {
//                // Delete Tour Package
//                int id;
//                cout << "Enter package ID to delete: ";
//                cin >> id;
//                bool found = false;
//                for (int i = 0; i < numTourPackages; ++i) {
//                    if (packageIDs[i] == id) {
//                        for (int j = i; j < numTourPackages - 1; ++j) {
//                            packageIDs[j] = packageIDs[j + 1];
//                            strcpy(packageNames[j], packageNames[j + 1]);
//                            strcpy(packageDescriptions[j], packageDescriptions[j + 1]);
//                            packagePrices[j] = packagePrices[j + 1];
//                            strcpy(packageItineraries[j], packageItineraries[j + 1]);
//                        }
//                        --numTourPackages;
//                        cout << "Tour package deleted successfully.\n";
//                        found = true;
//                        break;
//                    }
//                }
//                if (!found) {
//                    cout << "Package ID not found.\n";
//                }
//            }
//            else if (tourChoice == 4) {
//                // View Tour Packages
//                for (int i = 0; i < numTourPackages; ++i) {
//                    cout << "ID: " << packageIDs[i] << "\n";
//                    cout << "Name: " << packageNames[i] << "\n";
//                    cout << "Description: " << packageDescriptions[i] << "\n";
//                    cout << "Price: " << packagePrices[i] << "\n";
//                    cout << "Itinerary: " << packageItineraries[i] << "\n";
//                    cout << "--------------------------\n";
//                }
//            }
//            else {
//                cout << "Invalid choice.\n";
//            }
//        }
//        else if (choice == 2) {
//            cout << "1. Create Booking\n";
//            cout << "2. Modify Booking\n";
//            cout << "3. Cancel Booking\n";
//            cout << "4. View Bookings\n";
//            cout << "Enter your choice: ";
//            int bookingChoice;
//            cin >> bookingChoice;
//
//            if (bookingChoice == 1) {
//                // Create Booking
//                if (numBookings < 100) {
//                    bookingIDs[numBookings] = nextBookingID++;
//                    cout << "Enter package ID: ";
//                    cin >> bookingPackageIDs[numBookings];
//                    cout << "Enter user ID: ";
//                    cin >> bookingUserIDs[numBookings];
//                    cout << "Enter booking status: ";
//                    cin.ignore();
//                    cin.getline(bookingStatuses[numBookings], 20);
//                    cout << "Enter payment amount: ";
//                    cin >> bookingPayments[numBookings];
//                    numBookings++;
//                    cout << "Booking created successfully.\n";
//                }
//                else {
//                    cout << "Max bookings reached.\n";
//                }
//            }
//            else if (bookingChoice == 2) {
//                // Modify Booking
//                int id;
//                cout << "Enter booking ID to modify: ";
//                cin >> id;
//                bool found = false;
//                for (int i = 0; i < numBookings; ++i) {
//                    if (bookingIDs[i] == id) {
//                        cout << "Enter new package ID: ";
//                        cin >> bookingPackageIDs[i];
//                        cout << "Enter new user ID: ";
//                        cin >> bookingUserIDs[i];
//                        cout << "Enter new booking status: ";
//                        cin.ignore();
//                        cin.getline(bookingStatuses[i], 20);
//                        cout << "Enter new payment amount: ";
//                        cin >> bookingPayments[i];
//                        cout << "Booking updated successfully.\n";
//                        found = true;
//                        break;
//                    }
//                }
//                if (!found) {
//                    cout << "Booking ID not found.\n";
//                }
//            }
//            else if (bookingChoice == 3) {
//                // Cancel Booking
//                int id;
//                cout << "Enter booking ID to cancel: ";
//                cin >> id;
//                bool found = false;
//                for (int i = 0; i < numBookings; ++i) {
//                    if (bookingIDs[i] == id) {
//                        for (int j = i; j < numBookings - 1; ++j) {
//                            bookingIDs[j] = bookingIDs[j + 1];
//                            bookingPackageIDs[j] = bookingPackageIDs[j + 1];
//                            bookingUserIDs[j] = bookingUserIDs[j + 1];
//                            strcpy(bookingStatuses[j], bookingStatuses[j + 1]);
//                            bookingPayments[j] = bookingPayments[j + 1];
//                        }
//                        --numBookings;
//                        cout << "Booking cancelled successfully.\n";
//                        found = true;
//                        break;
//                    }
//                }
//                if (!found) {
//                    cout << "Booking ID not found.\n";
//                }
//            }
//            else if (bookingChoice == 4) {
//                // View Bookings
//                for (int i = 0; i < numBookings; ++i) {
//                    cout << "ID: " << bookingIDs[i] << "\n";
//                    cout << "Package ID: " << bookingPackageIDs[i] << "\n";
//                    cout << "User ID: " << bookingUserIDs[i] << "\n";
//                    cout << "Status: " << bookingStatuses[i] << "\n";
//                    cout << "Payment: " << bookingPayments[i] << "\n";
//                    cout << "--------------------------\n";
//                }
//            }
//            else {
//                cout << "Invalid choice.\n";
//            }
//        }
//        else if (choice == 3) {
//            cout << "1. Add Hotel\n";
//            cout << "2. Update Hotel\n";
//            cout << "3. Remove Hotel\n";
//            cout << "4. View Hotels\n";
//            cout << "Enter your choice: ";
//            int hotelChoice;
//            cin >> hotelChoice;
//
//            if (hotelChoice == 1) {
//                // Add Hotel
//                if (numHotels < 100) {
//                    hotelIDs[numHotels] = nextHotelID++;
//                    cout << "Enter hotel name: ";
//                    cin.ignore();
//                    cin.getline(hotelNames[numHotels], 100);
//                    cout << "Enter hotel location: ";
//                    cin.getline(hotelLocations[numHotels], 100);
//                    cout << "Enter number of rooms available: ";
//                    cin >> hotelRoomsAvailable[numHotels];
//                    cout << "Enter room price: ";
//                    cin >> hotelRoomPrices[numHotels];
//                    numHotels++;
//                    cout << "Hotel added successfully.\n";
//                }
//                else {
//                    cout << "Max hotels reached.\n";
//                }
//            }
//            else if (hotelChoice == 2) {
//                // Update Hotel
//                int id;
//                cout << "Enter hotel ID to update: ";
//                cin >> id;
//                bool found = false;
//                for (int i = 0; i < numHotels; ++i) {
//                    if (hotelIDs[i] == id) {
//                        cout << "Enter new hotel name: ";
//                        cin.ignore();
//                        cin.getline(hotelNames[i], 100);
//                        cout << "Enter new hotel location: ";
//                        cin.getline(hotelLocations[i], 100);
//                        cout << "Enter new number of rooms available: ";
//                        cin >> hotelRoomsAvailable[i];
//                        cout << "Enter new room price: ";
//                        cin >> hotelRoomPrices[i];
//                        cout << "Hotel updated successfully.\n";
//                        found = true;
//                        break;
//                    }
//                }
//                if (!found) {
//                    cout << "Hotel ID not found.\n";
//                }
//            }
//            else if (hotelChoice == 3) {
//                // Remove Hotel
//                int id;
//                cout << "Enter hotel ID to remove: ";
//                cin >> id;
//                bool found = false;
//                for (int i = 0; i < numHotels; ++i) {
//                    if (hotelIDs[i] == id) {
//                        for (int j = i; j < numHotels - 1; ++j) {
//                            hotelIDs[j] = hotelIDs[j + 1];
//                            strcpy(hotelNames[j], hotelNames[j + 1]);
//                            strcpy(hotelLocations[j], hotelLocations[j + 1]);
//                            hotelRoomsAvailable[j] = hotelRoomsAvailable[j + 1];
//                            hotelRoomPrices[j] = hotelRoomPrices[j + 1];
//                        }
//                        --numHotels;
//                        cout << "Hotel removed successfully.\n";
//                        found = true;
//                        break;
//                    }
//                }
//                if (!found) {
//                    cout << "Hotel ID not found.\n";
//                }
//            }
//            else if (hotelChoice == 4) {
//                // View Hotels
//                for (int i = 0; i < numHotels; ++i) {
//                    cout << "ID: " << hotelIDs[i] << "\n";
//                    cout << "Name: " << hotelNames[i] << "\n";
//                    cout << "Location: " << hotelLocations[i] << "\n";
//                    cout << "Rooms Available: " << hotelRoomsAvailable[i] << "\n";
//                    cout << "Room Price: " << hotelRoomPrices[i] << "\n";
//                    cout << "--------------------------\n";
//                }
//            }
//            else {
//                cout << "Invalid choice.\n";
//            }
//        }
//        else if (choice == 4) {
//            cout << "1. Add Review\n";
//            cout << "2. View Reviews\n";
//            cout << "Enter your choice: ";
//            int reviewChoice;
//            cin >> reviewChoice;
//
//            if (reviewChoice == 1) {
//                // Add Review
//                if (numReviews < 100) {
//                    reviewIDs[numReviews] = nextReviewID++;
//                    cout << "Enter hotel ID: ";
//                    cin >> reviewHotelIDs[numReviews];
//                    cout << "Enter user ID: ";
//                    cin >> reviewUserIDs[numReviews];
//                    cout << "Enter rating (1-5): ";
//                    cin >> reviewRatings[numReviews];
//                    cout << "Enter comments: ";
//                    cin.ignore();
//                    cin.getline(reviewComments[numReviews], 256);
//                    numReviews++;
//                    cout << "Review added successfully.\n";
//                }
//                else {
//                    cout << "Max reviews reached.\n";
//                }
//            }
//            else if (reviewChoice == 2) {
//                // View Reviews
//                for (int i = 0; i < numReviews; ++i) {
//                    cout << "ID: " << reviewIDs[i] << "\n";
//                    cout << "Hotel ID: " << reviewHotelIDs[i] << "\n";
//                    cout << "User ID: " << reviewUserIDs[i] << "\n";
//                    cout << "Rating: " << reviewRatings[i] << "\n";
//                    cout << "Comments: " << reviewComments[i] << "\n";
//                    cout << "--------------------------\n";
//                }
//            }
//            else {
//                cout << "Invalid choice.\n";
//            }
//        }
//        else if (choice == 5) {
//            break;
//        }
//        else {
//            cout << "Invalid choice. Try again.\n";
//        }
//    }
//
//    return 0;
//}
